<?php

namespace N1ebieski\IDir\Cache;

use Illuminate\Support\Carbon;
use N1ebieski\IDir\Models\Dir;
use N1ebieski\ICore\Models\Tag\Tag;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Support\Collection as Collect;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Contracts\Cache\Repository as Cache;
use Illuminate\Contracts\Config\Repository as Config;

/**
 * [DirCache description]
 */
class DirCache
{
    /**
     * Dir model
     * @var Dir
     */
    protected $dir;

    /**
     * Cache driver
     * @var Cache
     */
    protected $cache;

    /**
     * Undocumented variable
     *
     * @var Carbon
     */
    protected $carbon;

    /**
     * Configuration
     * @var int
     */
    protected $minutes;

    /**
     * [private description]
     * @var Collect
     */
    protected $collect;

    /**
     * Undocumented function
     *
     * @param Dir $dir
     * @param Cache $cache
     * @param Config $config
     * @param Carbon $carbon
     * @param Collect $collect
     */
    public function __construct(
        Dir $dir,
        Cache $cache,
        Config $config,
        Carbon $carbon,
        Collect $collect
    ) {
        $this->dir = $dir;

        $this->cache = $cache;
        $this->config = $config;
        $this->carbon = $carbon;
        $this->collect = $collect;

        $this->minutes = $config->get('cache.minutes');
    }

    /**
     * [getForWebByFilter description]
     * @param  int                  $page [description]
     * @return LengthAwarePaginator|null       [description]
     */
    public function getForWebByFilter(int $page) : ?LengthAwarePaginator
    {
        return $this->cache->tags(['dirs'])->get("dir.paginateByFilter.{$page}");
    }

    /**
     * [putForWebByFilter description]
     * @param  LengthAwarePaginator $dirs [description]
     * @param  int                  $page     [description]
     * @return bool                           [description]
     */
    public function putForWebByFilter(LengthAwarePaginator $dirs, int $page) : bool
    {
        return $this->cache->tags(['dirs'])
            ->put(
                "dir.paginateByFilter.{$page}",
                $dirs,
                $this->carbon->now()->addMinutes($this->minutes)
            );
    }

    /**
     * [rememberForWebByFilter description]
     * @param  array        $filter       [description]
     * @param  int          $page         [description]
     * @return LengthAwarePaginator       [description]
     */
    public function rememberForWebByFilter(array $filter, int $page) : LengthAwarePaginator
    {
        if ($this->collect->make($filter)->isNullItems()) {
            $dirs = $this->getForWebByFilter($page);
        }

        if (!isset($dirs) || !$dirs) {
            $dirs = $this->dir->makeRepo()->paginateForWebByFilter($filter);

            if ($this->collect->make($filter)->isNullItems()) {
                $this->putForWebByFilter($dirs, $page);
            }
        }

        return $dirs;
    }

    /**
     * Undocumented function
     *
     * @return string
     */
    public function rememberThumbnailUrl() : string
    {
        return $this->cache->remember(
            "dir.thumbnailUrl.{$this->dir->slug}",
            $this->carbon->now()->addDays($this->config->get('idir.dir.thumbnail.cache.days')),
            function () {
                return $this->config->get('idir.dir.thumbnail.cache.url')
                    .app('crypt.thumbnail')->encryptString($this->dir->url);
            }
        );
    }

    /**
     * Undocumented function
     *
     * @param Tag $tag
     * @param integer $page
     * @return LengthAwarePaginator|null
     */
    public function getByTagAndFilter(Tag $tag, int $page) : ?LengthAwarePaginator
    {
        return $this->cache->tags(['dirs'])->get("dir.paginateByTagAndFilter.{$tag->normalized}.{$page}");
    }

    /**
     * Undocumented function
     *
     * @param LengthAwarePaginator $dirs
     * @param Tag $tag
     * @param integer $page
     * @return boolean
     */
    public function putByTagAndFilter(LengthAwarePaginator $dirs, Tag $tag, int $page) : bool
    {
        return $this->cache->tags(['dirs'])
            ->put(
                "dir.paginateByTagAndFilter.{$tag->normalized}.{$page}",
                $dirs,
                $this->carbon->now()->addMinutes($this->minutes)
            );
    }

    /**
     * [rememberByTagAndFilter description]
     * @param  Tag                  $tag  [description]
     * @param  array                $filter  [description]
     * @param  int                  $page [description]
     * @return LengthAwarePaginator       [description]
     */
    public function rememberByTagAndFilter(Tag $tag, array $filter, int $page) : LengthAwarePaginator
    {
        if ($this->collect->make($filter)->isNullItems()) {
            $dirs = $this->getByTagAndFilter($tag, $page);
        }

        if (!isset($dirs) || !$dirs) {
            $dirs = $this->dir->makeRepo()->paginateByTagAndFilter($tag->name, $filter);

            if ($this->collect->make($filter)->isNullItems()) {
                $this->putByTagAndFilter($dirs, $tag, $page);
            }
        }

        return $dirs;
    }
    
    /**
     * Cache route binding of Dir
     * @param  string $slug [description]
     * @return Region|null       [description]
     */
    public function rememberBySlug(string $slug)
    {
        return $this->cache->tags(["dir.{$slug}"])->remember(
            "dir.firstBySlug.{$slug}",
            $this->carbon->now()->addMinutes($this->minutes),
            function () use ($slug) {
                return $this->dir->makeRepo()->firstBySlug($slug);
            }
        );
    }
    
    /**
     * [rememberLoadAllPublicRels description]
     * @return Dir [description]
     */
    public function rememberLoadAllPublicRels() : Dir
    {
        return $this->cache->tags(["dir.{$this->dir->slug}"])->remember(
            "dir.{$this->dir->slug}.loadAllPublicRels",
            $this->carbon->now()->addMinutes($this->minutes),
            function () {
                return $this->dir->loadAllPublicRels();
            }
        );
    }
    
    /**
     * [rememberRelated description]
     * @return Collection [description]
     */
    public function rememberRelated() : Collection
    {
        return $this->cache->tags(["dir.{$this->dir->slug}"])->remember(
            "dir.getRelated.{$this->dir->id}",
            $this->carbon->now()->addMinutes($this->minutes),
            function () {
                return $this->dir->makeRepo()->getRelated();
            }
        );
    }

    /**
     * [rememberLatestForHome description]
     * @return Collection [description]
     */
    public function rememberLatestForHome() : Collection
    {
        return $this->cache->tags(["dirs"])->remember(
            "dir.getLatestForHome",
            $this->carbon->now()->addMinutes($this->minutes),
            function () {
                return $this->dir->makeRepo()->getLatestForHome();
            }
        );
    }

    /**
     * Undocumented function
     *
     * @param array $component
     * @return Collection
     */
    public function rememberAdvertisingPrivilegedByComponent(array $component) : Collection
    {
        return $this->cache->tags(["dirs"])->remember(
            "dir.getAdvertisingPrivilegedByComponent",
            $this->carbon->now()->addMinutes($this->minutes),
            function () use ($component) {
                return $this->dir->makeRepo()->getAdvertisingPrivilegedByComponent($component);
            }
        );
    }
}
