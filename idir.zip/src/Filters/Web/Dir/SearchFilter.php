<?php

namespace N1ebieski\IDir\Filters\Web\Dir;

use N1ebieski\ICore\Filters\Filter;
use N1ebieski\ICore\Filters\Traits\HasOrderBy;

/**
 * [SearchFilter description]
 */
class SearchFilter extends Filter
{
    use HasOrderBy;
}
