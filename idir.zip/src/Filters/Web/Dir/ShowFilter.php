<?php

namespace N1ebieski\IDir\Filters\Web\Dir;

use N1ebieski\ICore\Filters\Filter;
use N1ebieski\ICore\Filters\Traits\HasOrderBy;

/**
 * [ShowFilter description]
 */
class ShowFilter extends Filter
{
    use HasOrderBy;
}