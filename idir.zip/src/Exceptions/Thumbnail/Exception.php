<?php

namespace N1ebieski\IDir\Exceptions\Thumbnail;

use N1ebieski\IDir\Exceptions\CustomException;

class Exception extends CustomException
{
    //
}
