<?php

namespace N1ebieski\IDir\Exceptions\Payment\Cashbill;

use N1ebieski\IDir\Exceptions\Payment\Exception as PaymentException;

class Exception extends PaymentException
{
    //
}
