<?php

namespace N1ebieski\IDir\Exceptions\Payment\Cashbill\Codes\SMS;

use N1ebieski\IDir\Exceptions\Payment\Cashbill\Exception;

class InvalidNumberException extends Exception
{
}
