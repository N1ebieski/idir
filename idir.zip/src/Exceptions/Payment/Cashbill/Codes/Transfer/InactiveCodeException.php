<?php

namespace N1ebieski\IDir\Exceptions\Payment\Cashbill\Codes\Transfer;

use N1ebieski\IDir\Exceptions\Payment\Cashbill\Exception;

class InactiveCodeException extends Exception
{
}
