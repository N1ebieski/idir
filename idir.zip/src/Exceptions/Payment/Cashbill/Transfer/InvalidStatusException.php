<?php

namespace N1ebieski\IDir\Exceptions\Payment\Cashbill\Transfer;

use N1ebieski\IDir\Exceptions\Payment\Cashbill\Exception;

class InvalidStatusException extends Exception
{
}
