jQuery(document).ready(function () {
    // $('.carousel').carousel();
});