require('~/../vendor/n1ebieski/icore/resources/js/web/web.js');

require('../web/cssmap-poland/jquery.cssmap.min.js');

