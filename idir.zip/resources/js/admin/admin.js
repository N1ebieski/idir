require('~/../vendor/n1ebieski/icore/resources/js/admin/admin.js');
