<?php

return [
    'code' => 'Podany kod jest nieprawidłowy.',
    'backlink_url' => 'Jeśli podano url, link zwrotny musi być również na tej domenie.',
    'backlink' => 'Nie znaleziono linka zwrotnego pod tym adresem.'
];
