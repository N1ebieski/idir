<?php

return [
    'import' => 'Uwaga: importer usunie dotychczasowe dane i zaimportuje nowe jako nowa instancja aplikacji.',
    'seed' => 'Import danych... (może potrwać nawet kilka godzin)'
];
