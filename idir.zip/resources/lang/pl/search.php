<?php

return [
    'dir' => [
        'dir' => 'katalog'
    ]
];
