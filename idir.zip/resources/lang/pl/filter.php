<?php

return [
    'group' => 'Grupa'
];
