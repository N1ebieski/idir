<?php

return [
    'dir' => [
        'dir' => 'Katalog',
    ]
];
