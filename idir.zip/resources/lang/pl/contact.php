<?php

return [
    'dir' => [
        'route' => [
            'show' => 'Kontakt z właścicielem wpisu'
        ],
        'success' => [
            'send' => 'Wiadomość została wysłana do właściciela wpisu.'
        ]
    ],
];
