<?php

return [
    'page' => [
        'edit_dir' => 'Wpisy'
    ]
];
