<?php

return [
    'regions' => 'Województwa'
];
