<?php

return [
    'value' => [
        'url' => [
            'url' => 'Adres URL',
            'route' => [
                'index' => 'Zbanowane adresy URL'
            ],
        ],
    ]
];
