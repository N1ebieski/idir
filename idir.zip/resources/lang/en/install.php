<?php

return [
    'ask_url' => 'Enter the address where the application will be installed'
];
